=================================================================
FILE
=================================================================

docs/MUSIC_BUILDERS_PACKET.md — execution packet for
docs/MUSIC_PLAYER_PLAN.md, written for a budget model to build from.

Claude, 2026-07-23. The plan says WHAT and WHY; this packet says
EXACTLY WHERE and HOW, and pre-writes the failure-prone code.

=================================================================
SHIPPED IN THIS PACKET (destination paths are real)
=================================================================

  services/MpdConnection.qml        protocol layer — NEARLY COMPLETE
  services/MusicService.qml         facade — NEARLY COMPLETE
  widgets/TopBar/MusicIndicator.qml bar item — Phase 2 complete,
                                    Phase 3 block commented
  docs/MUSIC_BUILDERS_PACKET.md     this file

NOT shipped (builder creates in later phases): MusicPanel.qml,
QueueView.qml, ArtistSearchView.qml, AlbumArt resolution.

=================================================================
PACKET v2 — AMENDMENTS (authoritative over the plan where they
conflict; incorporated after GPT's review of v1)
=================================================================

A. TRANSPORT IS UNIX-SOCKET ONLY for v1. The plan's D1 sentence
   about a 127.0.0.1:6600 fallback is SUPERSEDED — Phase 0 item 2
   makes the unix socket a hard requirement (one mpd.conf line).
   TCP would need a different transport type and stays deferred.
B. Reconnect teardown is reentrancy-guarded (tearingDown flag,
   connectGuard stopped before sockets drop) — shipped fixed.
C. Artist mode is rebuilt around STORED-PLAYLIST STAGING:
   (v3) plus ONE shared restoration pipeline for normal exit and
   automatic recovery — clear before every restore load, random
   restored on all paths, every restore command callback-chained
   (hard failures = queue integrity; soft = seek/pause fidelity,
   reported not blocking), stop-case validated, and BOTH temp
   playlists removed only after confirmed restore — so
   "qs-return-queue exists at startup" is unambiguous interrupted-
   session evidence. Aborted enters after a successful save also
   clean up. Original v2 text follows:
   searchaddpl into qs-working-artist (non-destructive), verify
   non-empty, save return queue, and only then clear+load — with
   automatic restore from qs-return-queue if the destructive window
   fails, and an ERROR state carrying manual-recovery instructions
   when even restore fails. The snapshot now includes queue
   position and play/pause/stop; restore is position-first with
   uri verification and re-applies paused/stopped (never blind
   `play`). Consume=1 refuses entry with a message.
D. The elapsed ticker is REFCOUNTED (panelOpened()/panelClosed());
   panels must never assign a shared bool — two monitors means two
   panels.
E. Old Phases 2 and 3 are MERGED (see below): the bar item ships
   together with a minimal panel shell so left-click opens the
   panel from day one — no temporary binding that retrains later.
F. Fixed playlist names (qs-return-queue/qs-working-artist) are an
   ACCEPTED RISK on this one-shell machine — the fixed return name
   is itself the crash-recovery mechanism. Documented in
   MusicService.qml; do not "fix" it.

=================================================================
RULES FOR THE EXECUTING MODEL — read before touching anything
=================================================================

1. NEVER invent Quickshell API. Treat MpdConnection.qml as a
   likely-correct ARCHITECTURE in plausible syntax, not trusted
   code: do NOT repair it by guessing equivalent properties. FIRST
   locate a working Socket implementation (this repository, the
   z-example caelestia files, or installed Quickshell examples),
   THEN adapt the skeleton to that confirmed API. Record every
   correction in the file's REVISION HISTORY.
2. Resolve every `VERIFY` and `TODO(builder)` marker in a phase
   before declaring that phase done. They are the checklist.
3. One phase per session. Live-test the gate before the next phase.
   No opportunistic edits outside the listed files (change-control
   rules in QUICKSHELL_MEMORY_STABILIZATION_PLAN.md apply).
4. Match house style exactly: //===== header blocks with FILE /
   PURPOSE / DESIGN NOTES / REVISION HISTORY, signed and dated.
   Copy the shape from any existing widget.
5. Pattern sources are named per task below. COPY those files'
   structure; do not freestyle equivalents.
6. Lifecycle laws (CODE_REVIEW_2026-07-22.md §10): windows created
   once and toggled, never destroyed/recreated; ListView+reuseItems
   for anything list-shaped, never Repeater for large models; static
   reused Processes; no always-running Timers.

=================================================================
REGISTRATION — services/qmldir (do this in Phase 1)
=================================================================

MusicService is a `pragma Singleton` and must be registered.
FIRST run `cat services/qmldir`, observe the exact format used by
the existing singletons (Audio, Network, Notifs, ...), and append
the MusicService line in that same format. MpdConnection is NOT a
singleton and needs no registration (same-directory type resolution
covers MusicService's use of it). If qmldir also lists non-singleton
types, mirror whatever the file already does — the existing file is
the spec.

=================================================================
PHASE 0 — environment (no shell edits; terminal only)
=================================================================

1. `systemctl --user status mpd` (or system unit) — running.
2. Unix socket: `grep bind_to_address ~/.config/mpd/mpd.conf`.
   If only TCP, ADD a line
   `bind_to_address "~/.config/mpd/socket"` and restart mpd.
   v1 requires the unix socket; TCP is out of scope (plan D1).
3. `mpc version` — note MPD protocol version (readpicture ≥ 0.21).
4. Tag audit (plan D3):
   `mpc list albumartist | wc -l` vs `mpc list artist | wc -l`,
   plus `mpc -f '%albumartist% | %artist%' listall | sort -u | head -40`.
   Record whether albumartist is populated. If largely empty, change
   BOTH `list albumartist` and `findadd albumartist` in
   MusicService.qml to the artist tag (one place each) and note it.
5. Hand-run every command in the plan's PROTOCOL CRIB via
   `nc -U <socket>` — especially save/rm/load round-trip and a
   quoted name: `findadd albumartist "AC\/DC"`-style cases.
   ALSO verify the STAGING command the v2 artist mode depends on:
   `searchaddpl qs-test albumartist "SomeName"` — confirm whether
   this form matches case-insensitively on this MPD version, and
   whether the filter form
   `searchaddpl qs-test "(AlbumArtist == \"SomeName\")"` (exact)
   is supported. Record WHICH form gives exact-match semantics;
   MusicService's staging call gets wired to that form in Phase 5.
   Clean up with `rm qs-test`.
6. Record queue + library size (`mpc playlist | wc -l`,
   `mpc stats`). >5k queue → flag for the plan's plchanges note.
7. Confirm the owner's bar click-binding choice (plan spec) — the
   skeleton ships the recommended default.
8. Art survey: `find <musicroot> -maxdepth 2 \( -iname 'cover.*' -o
   -iname 'folder.*' -o -iname 'front.*' \) | head` — note which
   names actually occur.

Gate: all eight items recorded in this file under a dated note.

=================================================================
PHASE 1 — service goes live
=================================================================

Files: services/MpdConnection.qml, services/MusicService.qml,
services/qmldir, plus the FOUR settings keys (see ST-1 block below —
but for THIS phase only add the UserPrefs keys with defaults;
settings-UI wiring is Phase 6. musicEnabled defaults true,
musicBarMaxLength 40, musicMpdAddress "", musicRootPath "").

Work items = the markers:
- MusicService `socketCandidates` TODO: build the candidate array.
  Look at how existing code reads env/home (Globals.qml,
  Settings.qml) and use the same accessor — VERIFY, don't invent.
- MpdConnection VERIFY items 1–3 (Socket/SplitParser syntax vs the
  z-example caelestia socket service; unix socket configured).
- Add nothing else. The FIFO/idle/backoff logic is DONE — if it
  appears broken, suspect the VERIFY items first.

Gate (all via terminal, shell running):
- `qs` log shows connect, no spam; kill mpd → one line + backoff
  climbing 1,2,4…30; start mpd → recovery within one backoff step.
- In a throwaway QML console or temporary debug Text in the bar:
  MusicService.title updates when `mpc next` runs; state follows
  `mpc toggle`; volume follows `mpc volume 50`. Zero polling: with
  everything idle, `strace -p <qspid> -e sendto` style checks or
  simply the mpd log show no periodic traffic.

=================================================================
PHASE 2 — bar item + minimal panel shell (v2: merged)
=================================================================

Files: widgets/TopBar/MusicIndicator.qml (shipped), TopBar.qml,
widgets/Music/MusicPanel.qml (new, MINIMAL: rows 1 and 3 only —
text metadata, transport buttons, shuffle/repeat; no art, no
progress, no volume yet).

- Insert MusicIndicator into TopBar's row next to NowPlaying. COPY
  the import/placement of NowPlaying exactly.
- Create the minimal MusicPanel and uncomment the popout block in
  MusicIndicator — left-click opens the panel from day one.
  onOpenChanged MUST call panelOpened()/panelClosed() (refcount —
  amendment D), never assign a bool.
- W-7 guard: the adjacent Separator's `visible` binds to the
  indicator's — find how the NowPlaying-adjacent separator handles
  this after the W-7 fix and do the same.
Gate: bar correct in all three states (playing / paused / mpd
stopped → widget gone, no dangling separator); left opens panel on
BOTH monitors' bars, middle/right/wheel act; panel transport works;
opening panels on both bars then closing ONE keeps the other's
elapsed display ticking (amendment D test); a day of daily driving.

=================================================================
PHASE 3 — panel completion (art, progress, volume)
=================================================================

Files: widgets/Music/MusicPanel.qml (extend), plus album art.

PATTERN SOURCES — copy structure, not vibes:
- Popout host + content-child contract: WallpaperPicker.qml
  (attachedPopout + WallpaperPickerContent with `controller` and
  `onCloseRequested`). MusicPanel is the content child.
- Buttons/rows: MenuButton.qml, ToggleRow.qml (one-way data down:
  panel emits, service state comes back — ToggleRow's header
  explains the pattern; shuffle/repeat lit-state works the same).
- Sliders (volume, progress): no existing slider in the codebase —
  build a minimal Rectangle-track + drag MouseArea; progress commits
  `MusicService.seekTo()` on RELEASE only (plan spec), volume may
  commit live but throttle to on-release if mpd log gets noisy.
- Layout per the plan's three rows. Theme tokens only — zero
  hardcoded colors/sizes; Theme.qml's header lists the vocabulary.
- Ticker gate: popout's onOpenChanged sets MusicService.ticking
  (already in the commented block).

ALBUM ART (plan D2) — build inside MusicPanel or a small
widgets/Music/AlbumArt.qml:
1. Sidecar: if Settings.musicRootPath !== "" derive
   dir = root + "/" + dirname(MusicService.fileUri), try the names
   found in Phase 0 §8 (Image.status === Image.Error → next
   candidate). Cap sourceSize (copy WallpaperPickerContent's
   thumbnail Image properties).
2. Embedded fallback: ONE static Process (copy WallpaperPicker.qml's
   queryProc shape: id, command array, StdioCollector, onExited) —
   but binary output must NOT go through StdioCollector: run
   `sh -c 'mpc readpicture "$1" > "$2" 2>/dev/null' art <uri> <dest>`
   with dest = $XDG_RUNTIME_DIR/qs-music-art/<md5>.img; onExited 0
   → set Image.source to dest. Cache cap in the same script line:
   `ls -t <dir> | tail -n +41 | xargs -r rm --`. md5 via the same
   approach ConfigManager uses for hashing if one exists — VERIFY;
   else `sh -c 'printf %s "$1" | md5sum | cut -d" " -f1'` as a
   pre-step is acceptable (still one static Process, chained).
3. Placeholder glyph when both miss.
Gate: panel matches the plan's row spec; art appears for a sidecar
album AND an embedded-only file; seek works; cache dir stays ≤ 40
files after playing 60+ distinct albums (script the check); soak
harness panel-toggle action added and 500 toggles show flat
thread/context counts (reuse the stabilization telemetry columns).

=================================================================
PHASE 4 — QueueView
=================================================================

File: widgets/Music/QueueView.qml, wired as a collapsible section
in MusicPanel (opening it closes ArtistSearchView and vice versa —
one bool in the panel decides which section is expanded).

- ListView, height cap ~420px, clip, reuseItems, ScrollBar.
- model: MusicService.queueModel; highlight row where
  model.id === MusicService.songId (id, NOT pos — plan spec).
- Click row → MusicService.playQueuePos(model.pos).
- On expand: positionViewAtIndex(currentIndex, ListView.Center) —
  compute currentIndex by scanning the model for songId once.
- Row visuals: copy the row shape from WallpaperPickerContent or
  the launcher results row — title left, artist muted, duration
  right (mm:ss helper).
Gate: external `mpc add`/`mpc del` reflects without interaction;
click-jump correct after `mpc shuffle`; 60fps scroll at the Phase 0
queue size; highlight follows track changes.

=================================================================
PHASE 5 — ArtistSearchView + artist mode
=================================================================

File: widgets/Music/ArtistSearchView.qml + the panel's breadcrumb
chip. Service logic already shipped — this phase is UI + the two
service TODOs.

- TextInput filters MusicService.artistList client-side
  (case-insensitive substring — launcher-style, no scoring); results
  ListView (reuseItems); click → MusicService.enterArtistMode(name);
  Enter with exactly one match → same.
- Breadcrumb chip in the panel while amState === "ON":
  「Artist: <amArtist>  ✕」, ✕ → exitArtistMode(). Tooltip/hover
  text: edits made in artist mode are discarded on exit (plan spec).
- amState ENTERING/EXITING → disable the chip + search clicks
  (visual busy), amError → surface it (copy how the panel shows
  conn.lastError).
- Service TODO: startup leftover detection (listplaylists →
  amReturnPlaylist present while OFF → chip offers restore).
- Wire the staging call to the exact-match form recorded in Phase 0
  item 5 (one line in enterArtistMode).
- TODO in refreshStatus: capture `consume` into amConsume.
Gate — plan Phase 5 gate plus the v2 recovery matrix:
- 20 consecutive enter/exit cycles diff-identical queue
  (`mpc playlist > before/after` + diff), position restored;
- pause BEFORE entering → exit returns PAUSED at the same song and
  offset; stop before entering → exit returns STOPPED (amendment C);
- duplicate-track queue (add the same file twice, position on the
  SECOND copy) → exit restores the second occurrence, not the first;
- forced staging failure (nonexistent artist string) → queue
  untouched, state unchanged, error shown;
- forced destructive-window failure (rename qs-working-artist via
  mpc between verify and load using a breakpoint delay, or simulate
  by `mpc rm` in a race) → automatic restore fires, queue back,
  error explains what happened;
- kill mpd mid-ENTERING → coherent state + lastError, and
  qs-return-queue still loadable by hand;
- consume on → entry refused with the documented message;
- quoted-name artist round-trips;
- (v3) after EVERY successful exit: `mpc lsplaylists` shows NEITHER
  qs-return-queue nor qs-working-artist — then restart qs and
  confirm NO leftover-recovery offer appears;
- (v3) random-off queue → enter (random goes on) → force the
  destructive-window failure → automatic recovery → `mpc status`
  shows random OFF again (the round-2 item-2 scenario, verbatim);
- (v3) enter with clear forced to fail after save (stop mpd between
  save and clear, restart) → state coherent AND no stranded
  qs-return-queue after the abort completes.

=================================================================
PHASE 6 — settings + soak integration (ST-1: SIX touchpoints/key)
=================================================================

Keys: musicEnabled, musicMpdAddress, musicRootPath,
musicBarMaxLength. For EACH, touch ALL SIX — the checklist that
CODE_REVIEW finding ST-1 exists to enforce:
  1. UserPrefs.qml     adapter property + validated setter (copy an
                       existing bool/string/int setter's clamp style)
  2. SettingsTransaction.qml  staged<Key> property
  3. SettingsTransaction.qml  shown<Key> fallthrough
  4. SettingsTransaction.qml  changes-diff entry
  5. ConfigManager.qml        apply-switch case
  6. qs-soak-test.py          settings-fuzz key list
Then run the transaction self-audit the same way the review did
(the scripted 65/65 check — extend expectation to 69/69) and fix
any miss BEFORE UI work.

Settings UI: a "Music" section on DesktopPage (plan D4 — no new
page). Copy an existing section's SectionLabel + rows.

Soak harness: add exclusion group "music" to
KNOWN_EXCLUSION_GROUPS and a music action family (panel toggle,
queue toggle, artist enter/exit against a random real artist,
transport commands) following how existing action functions are
written. Music actions must self-skip when MusicService is not
connected. Run a music-only soak (exclude everything else),
30+ min: flat thread/context counts, art cache ≤ cap, prefs
restore verifies.

Close-out: REVISION_HISTORY.md entry + a CODE_REVIEW addendum note
for the new files, matching the existing entries' shape.

=================================================================
TEST CHEAT SHEET (verification oracle = mpc)
=================================================================

state:      mpc status            volume: mpc volume 40
next/prev:  mpc next / mpc prev   seek:   mpc seek 50%
queue:      mpc playlist | head   add:    mpc add <uri>
artists:    mpc list albumartist | head
artist add: mpc findadd albumartist "Name"
save/load:  mpc save x / mpc load x / mpc rm x
staging:    mpc searchaddpl <pl> albumartist "Name" (see Ph.0 #5)
            mpc lsplaylists / nc: listplaylistinfo <pl>
The shell's displayed state must match mpc's answer after EVERY
one of these, within one idle wakeup.

=================================================================
REVISION HISTORY
=================================================================

2026-07-23  Claude: v3 after GPT round 2 — shared restoration
            pipeline, recovery restores random, chained+validated
            restore, post-restore temp-playlist cleanup (startup
            detection now unambiguous), aborted-enter cleanup,
            ticker doc corrected. Phase 5 gate extended to test all
            of it.
2026-07-23  Claude: v2 after GPT review. Amendments A-F (unix-only
            transport ruling; reentrancy-guarded reconnect; staged +
            recoverable artist mode with full snapshot; refcounted
            ticker; merged bar/panel-shell phase; fixed-name risk
            accepted). Rule 1 hardened to adapt-to-confirmed-API.
            Phase 0 gains the searchaddpl exact-match verification;
            Phase 5 gains the recovery test matrix.
2026-07-23  Claude: Initial packet — skeletons for MpdConnection,
            MusicService, MusicIndicator; per-phase work orders with
            gates; pattern-source map; ST-1 checklist; soak wiring.
