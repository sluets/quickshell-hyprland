//=============================================================================
// FILE
//=============================================================================
//
// services/MusicService.qml
//
//=============================================================================
// PURPOSE
//=============================================================================
//
// Claude: Public facade for the MPD music player (MUSIC_PLAYER_PLAN.md).
// The ONLY file widgets touch. Owns one MpdConnection, all parsing, the
// queue/artist models, and the artist-mode state machine. Registered as a
// singleton in services/qmldir (builder: see packet doc §qmldir — verify
// the existing file's format first, then append the matching line).
//
//=============================================================================
// DESIGN NOTES
//=============================================================================
//
// STATE FLOW: idle-socket events name a subsystem; refresh(subs) refetches
// only what that subsystem covers. Events are treated as "go look", never
// as truth (the watchdog's socket2 rule). On (re)connect, everything is
// fetched once.
//
// ELAPSED TIME: `elapsedBase` is MPD's value at the last status fetch;
// `elapsed` adds local wall-clock only while playing AND while at least
// one panel is open (plan D5 — no always-on timer). Panels call
// panelOpened()/panelClosed() from their popout's onOpenChanged — the
// refcount is the design; a shared bool is the multi-monitor bug (v2
// finding #5). NEVER reintroduce a bool here.
//
// ARTIST MODE is an explicit state machine (OFF/ENTERING/ON/EXITING) built
// from chained request callbacks. Every step checks ok; any failure lands
// back in a coherent state with lastError set. The return snapshot is taken
// ONLY when leaving OFF — switching artist-to-artist swaps against the
// ORIGINAL queue, never stacks snapshots.
//
// QUEUE MODEL is a ListModel mutated in place (clear+append on refetch).
// v1 refetches whole (fine to ~5k tracks per Phase 0 measurement); the
// plchanges upgrade path is documented in the plan and NOT built here.
//
//=============================================================================
// REVISION HISTORY
//=============================================================================
//
// 2026-07-23  Claude: v3 after GPT round 2. One shared restoration
//             pipeline (amRestoreQueue) for exit AND recovery: clear
//             before recovery load; random restored in recovery; every
//             restore command callback-chained with hard (queue
//             integrity) vs soft (seek/pause fidelity) failure classes;
//             stop-case validated; temp playlists removed only after
//             confirmed restore so startup leftover-detection is
//             unambiguous; aborted-enter-after-save cleanup added
//             (stranded-return-queue edge beyond GPT's list); stale
//             ticking doc line corrected to the refcount design.
// 2026-07-23  Claude: v2 after GPT review. Artist mode rebuilt around
//             stored-playlist STAGING (searchaddpl into qs-working-artist,
//             verified non-empty, before any destructive command) — the
//             clear->load window now loads a proven playlist and failure
//             triggers automatic restore from qs-return-queue; ERROR state
//             with manual-recovery instructions when even that fails.
//             Snapshot extended to pos + play/pause/stop; restore is
//             position-first with uri verification (duplicate tracks) and
//             re-applies paused/stopped instead of always playing. Ticker
//             refcounted (openPanelCount) for multi-monitor panels.
//             Consume=1 now refuses entry with a message.
// 2026-07-23  Claude: Initial skeleton for the builder's packet. Parsing,
//             commands, refresh routing, and the artist-mode machine are
//             complete; TODO markers are the builder's Phase checklist.
//
//=============================================================================

pragma Singleton

import Quickshell
import QtQuick
import qs.core

Singleton {
    id: root

    // ---- connection --------------------------------------------------------

    readonly property bool connected: conn.ready
    readonly property string lastError: amError !== "" ? amError : conn.lastError

    // ---- playback state (from `status` + `currentsong`) --------------------

    property string playState: "stop"      // play | pause | stop
    property int volume: -1                // -1 = unknown/no mixer
    property bool random: false
    property bool repeat: false
    property bool single: false
    property real elapsedBase: 0
    property real duration: 0
    property int songId: -1
    property int queueVersion: -1
    property int queueLength: 0

    property string title: ""
    property string artist: ""
    property string album: ""
    property string albumArtist: ""
    property string fileUri: ""

    readonly property bool isPlaying: playState === "play"

    // ---- elapsed ticker (plan D5; refcounted per GPT review finding #5) ----
    //
    // Two bars = two panels. A bool would let the second panel's close stop
    // the first panel's timer. Panels call panelOpened()/panelClosed() from
    // their popout's onOpenChanged instead of writing a shared bool.

    property int openPanelCount: 0
    readonly property bool ticking: openPanelCount > 0
    function panelOpened() { openPanelCount += 1; }
    function panelClosed() { openPanelCount = Math.max(0, openPanelCount - 1); }

    property real elapsed: elapsedBase
    Timer {
        interval: 1000
        repeat: true
        running: root.ticking && root.isPlaying
        onTriggered: root.elapsed = Math.min(root.elapsed + 1, root.duration > 0 ? root.duration : root.elapsed + 1)
    }
    onElapsedBaseChanged: elapsed = elapsedBase

    // ---- models ------------------------------------------------------------

    // Queue rows: { pos, id, title, artist, durationSecs }
    property ListModel queueModel: ListModel {}

    // All album artists (plan D3), refreshed on database changes.
    property var artistList: []

    // ---- artist mode -------------------------------------------------------
    //
    // v2 DESIGN (after GPT review findings #2/#3 — read before editing):
    //
    // The v1 sequence (clear -> findadd -> play) violated the plan's own
    // "never half-clear" rule: a findadd failure after a successful clear
    // left an empty queue with state OFF. MPD has no queue transaction, but
    // it has something better than hope: STORED-PLAYLIST STAGING.
    //
    //   ENTER: build the artist's tracks into stored playlist
    //          `qs-working-artist` (searchaddpl — touches NOTHING live),
    //          VERIFY it is non-empty, save the live queue to
    //          `qs-return-queue`, and only then `clear` + `load
    //          qs-working-artist`. The destructive window shrinks to
    //          clear->load of a playlist we just proved exists — and if
    //          even that load fails, RECOVER by loading qs-return-queue.
    //   SWITCH (artist while ON): same staging; the return snapshot is
    //          NOT retaken — always the original queue.
    //   EXIT:  one shared pipeline (amRestoreQueue) for BOTH normal exit
    //          and automatic recovery: clear -> load return -> random ->
    //          chained position/play-state restore -> rm both temp
    //          playlists -> OFF. Cleanup runs ONLY after confirmed
    //          restore, so "qs-return-queue exists at startup" is
    //          unambiguous crash evidence (v3, GPT round-2 items 1-3).
    //          On unrecoverable failure: ERROR with the queue name in the
    //          message — the playlist is never deleted on failure.
    //
    // SNAPSHOT captures exactly what artist mode itself mutates or moves,
    // nothing more (so user changes to repeat/single made DURING artist
    // mode survive exit): queue pos + file uri + elapsed + play/pause/stop
    // + random. Restore verifies the uri at the saved POSITION first
    // (duplicate-track safety), falls back to playlistfind, then re-applies
    // play state — a queue that was paused comes back paused, stopped
    // comes back stopped (v1 always played — GPT finding #3).
    //
    // States: OFF | ENTERING | ON | EXITING | ERROR. (SWITCHING reuses
    // ENTERING with fromOff=false; RECOVERING is transient inside the
    // failure handlers.) UI: ENTERING/EXITING disable controls; ERROR
    // shows amError and offers exitArtistMode() as "try restore again".
    //
    // Consume mode: read at enter; if consume=1, refuse with a message
    // (plan: warn, never silently toggle the user's setting).

    property string amState: "OFF"         // OFF | ENTERING | ON | EXITING | ERROR
    property string amArtist: ""
    property string amError: ""
    readonly property string amReturnPlaylist: "qs-return-queue"
    readonly property string amWorkingPlaylist: "qs-working-artist"
    property var amSnapshot: null  // { fileUri, pos, elapsed, playState, random }
    property string amConsume: "0" // updated from status by refreshStatus TODO(builder)

    function enterArtistMode(name) {
        if (amState === "ENTERING" || amState === "EXITING") return;
        if (amConsume === "1") {
            amError = "artist mode: consume mode is on in MPD — turn it off first (mpc consume off)";
            return;
        }
        amError = "";
        const fromOff = (amState === "OFF" || amState === "ERROR" && amSnapshot === null);
        const priorState = amState;
        amState = "ENTERING";

        // Step 1 — STAGE (non-destructive): rebuild the working playlist.
        conn.request("rm " + conn.quoteArg(amWorkingPlaylist), (_ok) => {
            // "no such playlist" ACK expected — ignore.
            // Phase 0 decides the exact add command (filter syntax vs
            // legacy) — builder wires the verified one here:
            conn.request("searchaddpl " + conn.quoteArg(amWorkingPlaylist)
                         + " albumartist " + conn.quoteArg(name), (ok1, _l1, err1) => {
                if (!ok1) { amState = priorState; amError = "artist mode: staging failed: " + err1; return; }
                // Step 2 — VERIFY non-empty before anything destructive.
                conn.request("listplaylistinfo " + conn.quoteArg(amWorkingPlaylist), (ok2, lines2, err2) => {
                    if (!ok2 || songBlocks(lines2).length === 0) {
                        amState = priorState;
                        amError = "artist mode: no tracks staged for " + name + (err2 ? " (" + err2 + ")" : "");
                        return;
                    }
                    const commit = () => amCommitLoad(name, priorState);
                    if (fromOff) {
                        // Step 3 — snapshot + save the REAL queue, once.
                        amSnapshot = {
                            fileUri: fileUri,
                            pos: queuePosOfSong(songId),
                            elapsed: elapsed,
                            playState: playState,
                            random: random
                        };
                        conn.request("rm " + conn.quoteArg(amReturnPlaylist), (_ok3) => {
                            conn.request("save " + conn.quoteArg(amReturnPlaylist), (ok4, _l4, err4) => {
                                if (!ok4) { amState = priorState; amSnapshot = null;
                                            amError = "artist mode: could not save return queue: " + err4; return; }
                                commit();
                            });
                        });
                    } else {
                        commit();   // switching: original snapshot stands
                    }
                });
            });
        });
    }

    // Step 4 — the only destructive window: clear + load a playlist we just
    // verified. Failure here triggers immediate RECOVERY from the return
    // queue rather than reporting a state the queue no longer matches.
    function amCommitLoad(name, priorState) {
        conn.request("clear", (ok, _l, err) => {
            if (!ok) return amAbortCleanup(priorState, "artist mode: clear failed: " + err);
            conn.request("load " + conn.quoteArg(amWorkingPlaylist), (ok2, _l2, err2) => {
                if (!ok2) return amRecover("loading staged artist queue failed: " + err2);
                conn.request("random 1", null);
                conn.request("play", (ok3, _l3, err3) => {
                    if (!ok3) { amError = "artist mode: play failed: " + err3; }
                    amArtist = name;
                    amState = "ON";
                });
            });
        });
    }

    function exitArtistMode() {
        if (amState !== "ON" && amState !== "ERROR") return;
        amError = "";
        amState = "EXITING";
        amRestoreQueue((ok, detail) => {
            if (!ok) return amDead("restoring your queue failed: " + detail);
            amArtist = "";
            amSnapshot = null;
            amState = "OFF";
            if (detail !== "") amError = "artist mode ended (" + detail + ")";
        });
    }

    // ---- THE ONE RESTORATION PIPELINE (v3, GPT round-2 item 2) ------------
    //
    // Used by normal exit AND automatic recovery — two subtly different
    // restore paths were the drift risk. Sequence, every step
    // callback-chained and checked (round-2 item 3 — nothing reports done
    // until MPD confirmed it):
    //
    //   clear                       (item 6: never load onto partial state)
    //   load qs-return-queue        (hard-fail -> done(false))
    //   random <snapshot>           (hard-fail -> done(false))
    //   position/elapsed/play-state (chained; soft failures collected)
    //   validate stopped stays stopped (stop-case only)
    //   rm both temp playlists      (item 1: only AFTER confirmed restore;
    //                                best-effort — failures reported, not
    //                                blocking, since a stale leftover only
    //                                costs one declined startup offer)
    //   done(true, warnings)
    //
    // HARD vs SOFT: queue integrity (clear/load/random) is hard — the
    // feature's promise is "your queue comes back". Sub-second position
    // fidelity (seek/pause) is soft — reported in `detail`, never blocks
    // OFF. This distinction is deliberate; do not promote seek failures to
    // hard without a reason.

    function amRestoreQueue(done) {
        const snap = amSnapshot;
        let warnings = [];
        conn.request("clear", (ok, _l, err) => {
            if (!ok) return done(false, "clear failed: " + err);
            conn.request("load " + conn.quoteArg(amReturnPlaylist), (ok2, _l2, err2) => {
                if (!ok2) return done(false, "load " + amReturnPlaylist + " failed: " + err2);
                conn.request("random " + (snap && snap.random ? 1 : 0), (ok3, _l3, err3) => {
                    if (!ok3) return done(false, "random restore failed: " + err3);
                    amRestorePosition(snap, warnings, () => {
                        amCleanupPlaylists(warnings, () => {
                            done(true, warnings.join("; "));
                        });
                    });
                });
            });
        });
    }

    // Position + play-state restore, fully chained (round-2 item 3).
    function amRestorePosition(snap, warnings, done) {
        if (!snap || snap.fileUri === "") {
            if (snap && snap.playState === "play")
                return conn.request("play", (_ok) => done());
            return amValidateStopped(snap, warnings, done);
        }
        const applyAt = (pos) => {
            if (snap.playState === "stop")
                return amValidateStopped(snap, warnings, done);
            conn.request("play " + pos, (okP, _lP, errP) => {
                if (!okP) { warnings.push("play-at-position failed: " + errP);
                            return done(); }
                const afterSeek = () => {
                    if (snap.playState !== "pause") return done();
                    conn.request("pause 1", (okZ, _lZ, errZ) => {
                        if (!okZ) warnings.push("pause restore failed: " + errZ);
                        done();
                    });
                };
                if (snap.elapsed > 1) {
                    conn.request("seekcur " + Math.round(snap.elapsed), (okS, _lS, errS) => {
                        if (!okS) warnings.push("seek restore failed: " + errS);
                        afterSeek();
                    });
                } else {
                    afterSeek();
                }
            });
        };
        if (snap.pos >= 0) {
            conn.request("playlistinfo " + snap.pos, (ok, lines) => {
                const b = ok ? songBlocks(lines) : [];
                if (b.length > 0 && b[0].file === snap.fileUri)
                    return applyAt(snap.pos);
                amFindAndApply(snap, warnings, applyAt, done);
            });
        } else {
            amFindAndApply(snap, warnings, applyAt, done);
        }
    }

    function amFindAndApply(snap, warnings, applyAt, done) {
        conn.request("playlistfind file " + conn.quoteArg(snap.fileUri), (ok, lines) => {
            const b = ok ? songBlocks(lines) : [];
            if (b.length > 0 && b[0].Pos !== undefined)
                return applyAt(parseInt(b[0].Pos));
            warnings.push("original track not found in restored queue");
            if (snap.playState === "play") return conn.request("play", (_o) => done());
            done();
        });
    }

    // Stop-case validation (round-2 item 3): a loaded queue starts stopped,
    // but verify rather than assume; force stop if something is playing.
    function amValidateStopped(snap, warnings, done) {
        conn.request("status", (ok, lines) => {
            const s = ok ? kvPairs(lines) : {};
            if (s.state !== undefined && s.state !== "stop") {
                conn.request("stop", (okS, _l, errS) => {
                    if (!okS) warnings.push("could not re-stop restored queue: " + errS);
                    done();
                });
            } else done();
        });
    }

    // Temp-playlist cleanup (round-2 item 1): ONLY reached after confirmed
    // restore. Best-effort; the return playlist's absence is what makes
    // startup leftover-detection meaningful.
    function amCleanupPlaylists(warnings, done) {
        conn.request("rm " + conn.quoteArg(amWorkingPlaylist), (_ok) => {
            conn.request("rm " + conn.quoteArg(amReturnPlaylist), (ok2, _l2, err2) => {
                if (!ok2 && err2.indexOf("No such") < 0)
                    warnings.push("temp playlist cleanup incomplete: " + err2);
                done();
            });
        });
    }

    // Aborted-enter cleanup (v3, beyond GPT's list): an enter that fails
    // AFTER `save` but BEFORE anything destructive (e.g. clear rejected)
    // leaves the queue untouched yet strands qs-return-queue — the same
    // false-crash-evidence bug as item 1 on a different edge. Called on
    // every abort-to-OFF path that follows a successful save.
    function amAbortCleanup(priorState, message) {
        const finish = () => { amState = priorState;
                               if (priorState === "OFF") amSnapshot = null;
                               amError = message; };
        if (priorState !== "OFF")   // switching: return queue MUST survive
            return finish();
        amCleanupPlaylists([], finish);
    }

    // Recovery after a destructive-window failure DURING enter (v3: full
    // shared pipeline — restores random too, per round-2 item 2's exact
    // scenario).
    function amRecover(why) {
        amRestoreQueue((ok, detail) => {
            if (!ok) return amDead(why + "; automatic restore also failed: " + detail);
            amArtist = "";
            amSnapshot = null;
            amState = "OFF";
            amError = "artist mode: " + why + " — your queue was restored"
                    + (detail !== "" ? " (" + detail + ")" : "");
        });
    }

    function amDead(why) {
        amState = "ERROR";
        amError = "artist mode: " + why
                + " — your queue is saved in MPD as '" + amReturnPlaylist
                + "' (recover manually with: mpc load " + amReturnPlaylist
                + "). Retry restore from the panel.";
    }

    // Queue position of a song id via the current model (cheap, local).
    function queuePosOfSong(id) {
        for (let i = 0; i < queueModel.count; i++)
            if (queueModel.get(i).id === id)
                return queueModel.get(i).pos;
        return -1;
    }

    // TODO(builder, Phase 5): refreshStatus also captures `consume` into
    // amConsume (one line in the kvPairs block).
    // TODO(builder, Phase 5): startup leftover detection — if
    // `listplaylists` shows amReturnPlaylist while amState is OFF, surface
    // a restore offer in the panel per the plan's crash-recovery note.
    // NOTE(accepted risk, GPT review): amReturnPlaylist is a fixed name; a
    // second shell instance or manual MPD use could overwrite it. This is a
    // one-shell machine and the fixed name IS the crash-recovery mechanism.
    // Documented, not "fixed".

    // ---- commands (widgets call these; all one-liners) ---------------------

    function playPause() { conn.request(isPlaying ? "pause 1" : (playState === "pause" ? "pause 0" : "play"), null); }
    function next()      { conn.request("next", null); }
    function previous()  { conn.request("previous", null); }
    function seekTo(seconds) { conn.request("seekcur " + Math.max(0, Math.round(seconds)), null); }
    function setVolume(v)    { conn.request("setvol " + Math.max(0, Math.min(100, Math.round(v))), null); }
    function toggleRandom()  { conn.request("random " + (random ? 0 : 1), null); }
    function toggleRepeat()  { conn.request("repeat " + (repeat ? 0 : 1), null); }
    function toggleSingle()  { conn.request("single " + (single ? 0 : 1), null); }
    function playQueuePos(pos) { conn.request("play " + pos, null); }

    // ---- parsing helpers ---------------------------------------------------

    function kvPairs(lines) {
        const o = {};
        for (const line of lines) {
            const at = line.indexOf(": ");
            if (at > 0)
                o[line.slice(0, at)] = line.slice(at + 2);
        }
        return o;
    }

    // playlistinfo / find results: repeated blocks, each starting "file:".
    function songBlocks(lines) {
        const out = [];
        let cur = null;
        for (const line of lines) {
            const at = line.indexOf(": ");
            if (at <= 0) continue;
            const k = line.slice(0, at), v = line.slice(at + 2);
            if (k === "file") { cur = { file: v }; out.push(cur); }
            else if (cur !== null) cur[k] = v;
        }
        return out;
    }

    // ---- refresh routing ---------------------------------------------------

    function refreshAll() {
        refreshStatus();
        refreshCurrentSong();
        refreshQueue();
        refreshArtists();
    }

    function refreshStatus() {
        conn.request("status", (ok, lines) => {
            if (!ok) return;
            const s = kvPairs(lines);
            playState = s.state || "stop";
            volume = s.volume !== undefined ? parseInt(s.volume) : -1;
            random = s.random === "1";
            repeat = s.repeat === "1";
            single = s.single === "1";   // "oneshot" also possible; treated as off
            elapsedBase = s.elapsed !== undefined ? parseFloat(s.elapsed) : 0;
            duration = s.duration !== undefined ? parseFloat(s.duration) : 0;
            songId = s.songid !== undefined ? parseInt(s.songid) : -1;
            queueLength = s.playlistlength !== undefined ? parseInt(s.playlistlength) : 0;
            const v = s.playlist !== undefined ? parseInt(s.playlist) : -1;
            if (v !== queueVersion) {
                queueVersion = v;
                // status noticed a queue change idle may not have named yet
                refreshQueue();
            }
        });
    }

    function refreshCurrentSong() {
        conn.request("currentsong", (ok, lines) => {
            if (!ok) return;
            const s = kvPairs(lines);
            fileUri = s.file || "";
            title = s.Title || fileUri.split("/").pop() || "";
            artist = s.Artist || "";
            album = s.Album || "";
            albumArtist = s.AlbumArtist || s.Artist || "";
        });
    }

    function refreshQueue() {
        conn.request("playlistinfo", (ok, lines) => {
            if (!ok) return;
            const blocks = songBlocks(lines);
            queueModel.clear();
            for (const b of blocks) {
                queueModel.append({
                    pos: b.Pos !== undefined ? parseInt(b.Pos) : -1,
                    id: b.Id !== undefined ? parseInt(b.Id) : -1,
                    title: b.Title || b.file.split("/").pop(),
                    artist: b.Artist || "",
                    durationSecs: b.duration !== undefined ? Math.round(parseFloat(b.duration)) : 0
                });
            }
        });
    }

    function refreshArtists() {
        conn.request("list albumartist", (ok, lines) => {
            if (!ok) return;
            const out = [];
            for (const line of lines)
                if (line.indexOf("AlbumArtist: ") === 0) {
                    const name = line.slice(13);
                    if (name !== "") out.push(name);
                }
            out.sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
            artistList = out;
        });
    }

    // ---- connection wiring -------------------------------------------------

    MpdConnection {
        id: conn
        enabled: Settings.musicEnabled
        // TODO(builder, Phase 1): candidate order per plan D1 —
        //   [ UserPrefs.musicMpdAddress ]  (only if non-empty)
        //   + Quickshell.env("XDG_RUNTIME_DIR") + "/mpd/socket"
        //   + home + "/.config/mpd/socket"
        // VERIFY the env/home accessors against qs.core Globals/Settings
        // conventions already used in this codebase before inventing one.
        socketCandidates: []

        onReadyChanged: if (ready) root.refreshAll()
        onSubsystemsChanged: subs => {
            for (const s of subs) {
                if (s === "player")   { root.refreshStatus(); root.refreshCurrentSong(); }
                else if (s === "mixer")    root.refreshStatus();
                else if (s === "options")  root.refreshStatus();
                else if (s === "playlist") { root.refreshStatus(); root.refreshQueue(); }
                else if (s === "database") root.refreshArtists();
            }
        }
    }
}
