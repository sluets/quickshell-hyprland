//=============================================================================
// FILE
//=============================================================================
//
// services/MpdConnection.qml
//
//=============================================================================
// PURPOSE
//=============================================================================
//
// Claude: MPD protocol transport for the music player (MUSIC_PLAYER_PLAN.md
// D1). NOT a singleton — MusicService.qml instantiates exactly one of these
// as a child and is the only file allowed to touch it. Widgets never import
// or reference this type.
//
// Two persistent unix-socket connections to MPD:
//   - command socket: send command, receive lines until OK/ACK, strict FIFO
//   - idle socket:    parked in `idle`, wakes with `changed: <subsystem>`
//                     lines, re-arms itself after every wakeup
//
// Reconnect uses exponential backoff (1s -> 2s -> ... -> 30s cap), reset on
// success — finding W-2 from CODE_REVIEW_2026-07-22.md applied preemptively.
//
//=============================================================================
// DESIGN NOTES
//=============================================================================
//
// PROTOCOL SHAPE (verified by hand in Phase 0 before this file is touched):
//   - On connect MPD greets with one line: "OK MPD <version>". Nothing may
//     be sent before that line arrives (HANDSHAKE state per socket).
//   - Command responses are zero or more "key: value" lines terminated by a
//     line that is exactly "OK", or an error line starting with "ACK ".
//   - MPD answers one connection's commands strictly in order, so a plain
//     FIFO of pending callbacks is sufficient. No IDs, no correlation.
//   - The idle connection NEVER carries normal commands and the command
//     connection NEVER sends `idle` — this removes any need for `noidle`
//     interleaving and keeps both parsers trivial.
//
// CONNECT-FAILURE DETECTION IS TIMER-GUARDED, deliberately: rather than
// depending on any particular Socket error signal, attemptConnect() arms a
// 3-second timer; if both sockets haven't completed the MPD handshake by
// then, the attempt is torn down and backoff advances. This is robust to
// API-surface differences and to half-open states. BUILDER: if qmllint or
// the qs docs show Socket exposing an explicit error signal in this
// Quickshell version, wiring it to failCurrentAttempt() is a welcome
// bonus — but the timer stays either way.
//
// SOCKET CANDIDATES: MusicService supplies an ordered path list (settings
// override first, then $XDG_RUNTIME_DIR/mpd/socket, then
// ~/.config/mpd/socket). Each failed attempt advances to the next candidate
// (wrapping), so a wrong first guess costs one backoff cycle, not forever.
//
// BUILDER — READ THIS FRAMING FIRST: this file is a LIKELY-CORRECT
// ARCHITECTURE expressed in plausible Quickshell syntax — it is NOT trusted
// working code. Do not repair it by guessing equivalent properties. FIRST
// locate a working Socket implementation (this repository, the z-example
// caelestia files, or installed Quickshell examples), THEN adapt this
// skeleton to that confirmed API, recording every correction below.
//
// BUILDER — VERIFY BEFORE FIRST RUN (do not skip; do not guess):
//   1. `import Quickshell.Io` provides Socket + SplitParser in this
//      Quickshell version. Reference usage exists in the caelestia example
//      files (z-example, hyprland socket2 service) — copy THAT syntax if
//      anything here fails to lint, and record the correction in the
//      revision history below.
//   2. Property names used here: Socket.path, Socket.connected (write true
//      to connect, false to disconnect), Socket.write(), SplitParser with
//      splitMarker "\n" and onRead delivering one line WITHOUT the marker.
//   3. MPD is configured with a unix socket (Phase 0 adds
//      `bind_to_address "~/.config/mpd/socket"` or the runtime-dir path to
//      mpd.conf if absent). TCP is out of scope for v1 (plan D1).
//
//=============================================================================
// REVISION HISTORY
//=============================================================================
//
// 2026-07-23  Claude: v2 after GPT review. Reentrancy fix: teardown paths
//             set tearingDown and stop connectGuard BEFORE dropping the
//             sockets, so self-inflicted onConnectedChanged events can no
//             longer re-enter failCurrentAttempt (double candidate-advance
//             / double backoff bug). Framing hardened: skeleton declared
//             pseudocode-until-verified, adapt-to-confirmed-API rule added.
// 2026-07-23  Claude: Initial skeleton for the builder's packet. Protocol
//             framing, FIFO, dual-socket layout, handshake states, backoff,
//             and the quoting helper are complete; VERIFY items above are
//             the builder's Phase 1 checklist.
//
//=============================================================================

import QtQuick
import Quickshell.Io

Item {
    id: root

    // ---- public surface (MusicService only) -------------------------------

    // Ordered unix-socket paths to try. Set once by MusicService before
    // setting `enabled: true`.
    property var socketCandidates: []

    // Master switch — bound by MusicService to Settings.musicEnabled (plus
    // its own readiness). false tears everything down and stops retrying.
    property bool enabled: false

    // True only when BOTH sockets have completed the MPD handshake.
    readonly property bool ready: cmdReady && idleReady

    // Human-readable last failure, for the panel's disconnected state.
    property string lastError: ""

    // Emitted once per idle wakeup with the deduplicated subsystem names,
    // e.g. ["player", "mixer"]. MusicService decides what to refetch.
    signal subsystemsChanged(var subsystems)

    // Send `command`; cb(ok: bool, lines: [string], errline: string) fires
    // when the terminal OK/ACK arrives. cb may be null for fire-and-forget.
    function request(command, cb) {
        if (!ready) {
            if (cb) cb(false, [], "not connected");
            return;
        }
        pending.push({ cb: cb || null, lines: [] });
        cmdSocket.write(command + "\n");
        cmdSocket.flush();
    }

    // MPD argument quoting: wrap in double quotes, escape backslash then
    // quote. Used for EVERY user-derived value (artist names, uris,
    // playlist names). Tested in Phase 0 against names containing " and \.
    function quoteArg(s) {
        return "\"" + String(s).replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\"";
    }

    // ---- internals ---------------------------------------------------------

    property bool cmdReady: false
    property bool idleReady: false
    property bool tearingDown: false
    property int candidateIndex: 0
    property real backoffSeconds: 1
    readonly property real backoffMax: 30
    property var pending: []            // [{cb, lines}] — command FIFO
    property var idleSeen: ({})         // dedup set for one idle wakeup

    readonly property string idleSubsystems: "player mixer options playlist database"

    onEnabledChanged: {
        if (enabled) {
            backoffSeconds = 1;
            attemptConnect();
        } else {
            teardown("disabled");
        }
    }

    onReadyChanged: {
        if (ready) {
            backoffSeconds = 1;
            lastError = "";
            armIdle();
        }
    }

    function currentPath() {
        if (socketCandidates.length === 0)
            return "";
        return socketCandidates[candidateIndex % socketCandidates.length];
    }

    function attemptConnect() {
        if (!enabled)
            return;
        const p = currentPath();
        if (p === "") {
            lastError = "no MPD socket candidates configured";
            return;
        }
        cmdSocket.path = p;
        idleSocket.path = p;
        cmdSocket.connected = true;
        idleSocket.connected = true;
        connectGuard.restart();
    }

    function failCurrentAttempt(reason) {
        // REENTRANCY GUARD (packet v2, GPT review finding #1): teardown sets
        // Socket.connected = false, which fires onConnectedChanged ->
        // handleDisconnect() -> back here. Without the guard, one failure
        // advances the candidate twice and doubles backoff twice.
        if (tearingDown)
            return;
        tearingDown = true;
        connectGuard.stop();          // BEFORE touching sockets — its
                                      // .running is part of the reentry path
        teardownSockets();
        tearingDown = false;
        lastError = reason + " (" + currentPath() + ")";
        candidateIndex = (candidateIndex + 1) % Math.max(1, socketCandidates.length);
        if (enabled) {
            retryTimer.interval = backoffSeconds * 1000;
            backoffSeconds = Math.min(backoffSeconds * 2, backoffMax);
            retryTimer.restart();
        }
    }

    function teardown(reason) {
        tearingDown = true;
        connectGuard.stop();
        retryTimer.stop();
        teardownSockets();
        tearingDown = false;
        if (reason !== "")
            lastError = reason;
    }

    function teardownSockets() {
        // Fail every in-flight request before dropping state — callers must
        // never wait forever on a callback (artist-mode state machine
        // depends on this).
        const stale = pending;
        pending = [];
        for (const req of stale)
            if (req.cb) req.cb(false, req.lines, "connection lost");
        cmdReady = false;
        idleReady = false;
        idleSeen = ({});
        cmdSocket.connected = false;
        idleSocket.connected = false;
    }

    function armIdle() {
        idleSeen = ({});
        idleSocket.write("idle " + idleSubsystems + "\n");
        idleSocket.flush();
    }

    // If either socket drops while we believed we were ready, treat it as a
    // full connection loss: MPD restarting kills both anyway, and mixed
    // half-states are not worth modeling. The tearingDown check makes
    // self-inflicted disconnects (our own teardown) inert.
    function handleDisconnect() {
        if (!enabled || tearingDown)
            return;
        if (cmdReady || idleReady || connectGuard.running)
            failCurrentAttempt("connection lost");
    }

    Timer {
        id: connectGuard
        interval: 3000
        repeat: false
        onTriggered: {
            if (!root.ready)
                root.failCurrentAttempt("connect/handshake timeout");
        }
    }

    Timer {
        id: retryTimer
        repeat: false
        onTriggered: root.attemptConnect()
    }

    Socket {
        id: cmdSocket
        onConnectedChanged: if (!connected) root.handleDisconnect()
        parser: SplitParser {
            splitMarker: "\n"
            onRead: line => {
                if (!root.cmdReady) {
                    if (line.indexOf("OK MPD") === 0)
                        root.cmdReady = true;
                    return;
                }
                if (line === "OK") {
                    const req = root.pending.shift();
                    if (req && req.cb) req.cb(true, req.lines, "");
                } else if (line.indexOf("ACK") === 0) {
                    const req = root.pending.shift();
                    if (req && req.cb) req.cb(false, req.lines, line);
                } else if (root.pending.length > 0) {
                    root.pending[0].lines.push(line);
                }
            }
        }
    }

    Socket {
        id: idleSocket
        onConnectedChanged: if (!connected) root.handleDisconnect()
        parser: SplitParser {
            splitMarker: "\n"
            onRead: line => {
                if (!root.idleReady) {
                    if (line.indexOf("OK MPD") === 0)
                        root.idleReady = true;
                    return;
                }
                if (line.indexOf("changed: ") === 0) {
                    root.idleSeen[line.slice(9).trim()] = true;
                } else if (line === "OK") {
                    const subs = Object.keys(root.idleSeen);
                    // Re-arm BEFORE notifying: the notification triggers
                    // command-socket fetches, and idle must already be
                    // parked so nothing between now and then is missed.
                    root.armIdle();
                    if (subs.length > 0)
                        root.subsystemsChanged(subs);
                }
                // ACK on the idle socket (bad subsystem name) would loop
                // forever if re-armed blindly — treat it as fatal for the
                // attempt instead.
                else if (line.indexOf("ACK") === 0) {
                    root.failCurrentAttempt("idle rejected: " + line);
                }
            }
        }
    }
}
