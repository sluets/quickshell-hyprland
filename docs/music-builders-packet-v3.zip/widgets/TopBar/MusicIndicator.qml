//=============================================================================
// FILE
//=============================================================================
//
// widgets/TopBar/MusicIndicator.qml
//
//=============================================================================
// PURPOSE
//=============================================================================
//
// Claude: MPD now-playing bar item (MUSIC_PLAYER_PLAN.md Phase 2), sibling
// of NowPlaying.qml — that widget keeps serving MPRIS (browsers etc.); this
// one is MPD-only via MusicService. Without an mpd-mpris bridge the two can
// never double-report one source.
//
// Phase 2 ships this file WITHOUT the popout (transport clicks act
// directly). Phase 3 uncomments the BarPopout block once MusicPanel.qml
// exists — pattern copied from WallpaperPicker.qml's attachedPopout.
//
//=============================================================================
// DESIGN NOTES
//=============================================================================
//
// CLICK BINDINGS — recommended default from the plan (owner may have chosen
// the alternative in Phase 0; check before building):
//   left = open/close panel · middle = play/pause · right = next ·
//   wheel = volume ±5
//
// W-7 GUARD: this widget collapses to width 0 when hidden. The Separator
// NEXT TO IT in TopBar.qml must bind `visible` to this widget's visible —
// copy however the NowPlaying-adjacent separator was fixed, and verify in
// the bar with MPD stopped.
//
//=============================================================================
// REVISION HISTORY
//=============================================================================
//
// 2026-07-23  Claude: v2 after GPT review. Bar item and minimal panel
//             shell are now ONE phase; left-click is panel-open from day
//             one (no-op until the panel compiles) instead of a temporary
//             play/pause that would retrain later. Popout block switched
//             to refcounted panelOpened()/panelClosed().
// 2026-07-23  Claude: Initial skeleton for the builder's packet.
//
//=============================================================================

import QtQuick
import qs.core
import qs.services

Item {
    id: root

    readonly property bool active: Settings.musicEnabled && MusicService.connected
                                   && MusicService.playState !== "stop"

    function truncate(str) {
        const max = Settings.musicBarMaxLength;
        return str.length > max ? str.slice(0, max - 1) + "…" : str;
    }

    readonly property string displayText: {
        if (!active) return "";
        const t = MusicService.title || "Unknown Title";
        const a = MusicService.albumArtist || MusicService.artist || "Unknown Artist";
        return truncate(t + " — " + a) + (MusicService.playState === "pause" ? "  ⏸" : "");
    }

    visible: active
    implicitWidth: visible ? content.implicitWidth : 0
    implicitHeight: content.implicitHeight

    Row {
        id: content
        spacing: Theme.spacingSmall
        Text {
            text: root.displayText
            color: Theme.colorForeground
            font.family: Theme.fontFamily
            font.pixelSize: Theme.fontSize
        }
    }

    MouseArea {
        anchors.fill: content
        acceptedButtons: Qt.LeftButton | Qt.MiddleButton | Qt.RightButton
        cursorShape: Qt.PointingHandCursor
        onClicked: mouse => {
            if (mouse.button === Qt.LeftButton) {
                // v2: build the minimal panel in the SAME phase and wire
                // left-click to it immediately — uncomment with the block
                // below. Until that compiles, left-click is a NO-OP by
                // design (finding #7: never ship a temporary binding that
                // later changes).
                // panelPopout.open = !panelPopout.open
            } else if (mouse.button === Qt.MiddleButton) {
                MusicService.playPause();
            } else if (mouse.button === Qt.RightButton) {
                MusicService.next();
            }
        }
        onWheel: wheel => {
            if (MusicService.volume < 0) return;   // no mixer
            const step = wheel.angleDelta.y > 0 ? 5 : -5;
            MusicService.setVolume(MusicService.volume + step);
        }
    }

    // ---- Phase 2 (v2: merged bar+panel-shell phase) — uncomment together
    // with a minimal MusicPanel (rows 1 and 3 only; art/progress/volume
    // arrive next phase). Left-click opens the panel from DAY ONE so no
    // temporary muscle memory forms (GPT review finding #7).
    // Pattern source: widgets/Wallpaper/WallpaperPicker.qml (attachedPopout).
    //
    // BarPopout {
    //     id: panelPopout
    //     anchorItem: root
    //     alignment: "center"
    //     onOpenChanged: open ? MusicService.panelOpened()
    //                         : MusicService.panelClosed()   // refcounted —
    //                           // NEVER assign a shared bool (finding #5)
    //     MusicPanel {
    //         controller: root
    //         onCloseRequested: panelPopout.open = false
    //     }
    // }
}
